var count = 1;
var countElement = document.querySelector('#count');
var logoImg = document.querySelector(".nav img");

function add1(){
    count++;
    countElement.innerText = 'The count is ' + count;
}

function subtract1(){
    count--;
    countElement.innerText = 'The count is ' + count;
}

function newShadow(element){
    element.classList.add('shadow');
}