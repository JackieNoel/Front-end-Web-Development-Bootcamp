// Print odd numbers 1-20
for(var i=1; i<21; i++){
    if(i%2 != 0){
        console.log(i);
    }
}







