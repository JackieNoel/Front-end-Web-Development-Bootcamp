// Print the sequence
var Array = [4, 2.5, 1, -0.5, -2, -3.5]
for(var y=0; y<Array.length; y++){
    console.log(Array[y])
}