var sum = 1;
for(var a=1; a<13; a++){
    sum = sum * a
}
console.log(sum)
