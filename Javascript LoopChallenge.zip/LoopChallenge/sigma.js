// Sigma
    var sum = 0
    for(var z=1; z<101; z++){
        sum = sum + z
    }
    console.log(sum)

