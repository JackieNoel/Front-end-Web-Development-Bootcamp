var counter = 1;
var counterElement = document.querySelector('#count');
var vid = document.querySelector('#beans');

function addYear(){
    counter++;
    counterElement.innerText = 'I am ' + counter + ' years old!'
}

function minusYear(){
    counter--;
    counterElement.innerText = 'I am ' + counter + ' years old!'
}

function hover(element){
    element.classList.add('color');
}

function remove(element){
    element.classList.remove('color');
}

function silly(element){
    element.innerText = 'Did this work?'
}

function hide(element){
    element.remove();
}

function disappear(element){
    element.remove();
}

function shadow(element){
    element.classList.add('shadow');
}

