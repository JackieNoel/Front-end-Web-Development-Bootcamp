function changePic(element){
    if(element.getAttribute("src") == "images/studentone.jpeg"){
        element.src = "images/studenttwo.jpeg"
    }else{
        element.src = "images/studentone.jpeg"
    }
}